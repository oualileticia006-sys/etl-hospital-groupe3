"""
dashboard/app.py
----------------
Dashboard Streamlit — Pipeline ETL Hospitalier
Groupe 3 — OUALI Leticia & BOUIMEDJ Wafi
"""

import os
import streamlit as st
import psycopg2
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# ──────────────────────────────────────────────
# Config page
# ──────────────────────────────────────────────
st.set_page_config(
    page_title="Dashboard Hospitalier",
    page_icon="🏥",
    layout="wide",
)

# ──────────────────────────────────────────────
# Connexion PostgreSQL
# ──────────────────────────────────────────────
@st.cache_resource
def get_conn():
    return psycopg2.connect(
        host=os.getenv("POSTGRES_HOST", "postgres"),
        port=os.getenv("POSTGRES_PORT", "5432"),
        database=os.getenv("POSTGRES_DB", "hospital_gold"),
        user=os.getenv("POSTGRES_USER", "hospital_admin"),
        password=os.getenv("POSTGRES_PASSWORD", ""),
    )

@st.cache_data(ttl=300)
def query(sql):
    conn = get_conn()
    return pd.read_sql(sql, conn)

# ──────────────────────────────────────────────
# Header
# ──────────────────────────────────────────────
st.markdown("""
<div style='background:#0D1B3E;padding:20px 30px;border-radius:8px;margin-bottom:20px'>
    <h1 style='color:white;margin:0;font-size:2rem'>🏥 Dashboard ETL Hospitalier</h1>
    <p style='color:#BAE6FD;margin:4px 0 0'>Apache Spark · Airflow · PostgreSQL — Groupe 3</p>
</div>
""", unsafe_allow_html=True)

# ──────────────────────────────────────────────
# KPIs synthétiques
# ──────────────────────────────────────────────
try:
    df_kpi = query("SELECT kpi_name, kpi_value, kpi_unit FROM gold_kpi_dashboard ORDER BY created_at DESC LIMIT 4")
    kpi_map = dict(zip(df_kpi["kpi_name"], zip(df_kpi["kpi_value"], df_kpi["kpi_unit"])))

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        val, unit = kpi_map.get("total_admissions", (0, ""))
        st.metric("📋 Total Admissions", f"{int(val):,}", unit)
    with col2:
        val, unit = kpi_map.get("duree_sejour_moy_jours", (0, ""))
        st.metric("🛏️ Durée moy. séjour", f"{val:.1f} j")
    with col3:
        val, unit = kpi_map.get("cout_moyen_admission", (0, ""))
        st.metric("💶 Coût moyen", f"{val:,.0f} $")
    with col4:
        val, unit = kpi_map.get("taux_readmission", (0, ""))
        st.metric("🔄 Taux réadmission", f"{val*100:.1f} %")
except Exception as e:
    st.warning(f"KPIs non disponibles : {e}")

st.divider()

# ──────────────────────────────────────────────
# Graphique 1 : Durée de séjour par service
# ──────────────────────────────────────────────
col_a, col_b = st.columns(2)

with col_a:
    st.subheader("🛏️ Durée moyenne de séjour par service")
    try:
        df = query("""
            SELECT service, ROUND(AVG(duree_sejour_moy)::numeric, 1) as duree_moy
            FROM gold_sejour_stats
            GROUP BY service ORDER BY duree_moy DESC
        """)
        fig = px.bar(df, x="duree_moy", y="service", orientation="h",
                     color="duree_moy", color_continuous_scale="Blues",
                     labels={"duree_moy": "Jours", "service": "Service"})
        fig.update_layout(coloraxis_showscale=False, plot_bgcolor="white",
                          margin=dict(l=10, r=10, t=10, b=10))
        st.plotly_chart(fig, use_container_width=True)
    except Exception as e:
        st.error(f"Erreur : {e}")

# ──────────────────────────────────────────────
# Graphique 2 : Top médicaments
# ──────────────────────────────────────────────
with col_b:
    st.subheader("💊 Top 10 médicaments prescrits")
    try:
        df = query("""
            SELECT medicament, SUM(nb_prescriptions) as total
            FROM gold_medication_stats
            GROUP BY medicament ORDER BY total DESC LIMIT 10
        """)
        fig = px.bar(df, x="total", y="medicament", orientation="h",
                     color="total", color_continuous_scale="Oranges",
                     labels={"total": "Prescriptions", "medicament": ""})
        fig.update_layout(coloraxis_showscale=False, plot_bgcolor="white",
                          margin=dict(l=10, r=10, t=10, b=10))
        st.plotly_chart(fig, use_container_width=True)
    except Exception as e:
        st.error(f"Erreur : {e}")

st.divider()

# ──────────────────────────────────────────────
# Graphique 3 : Admissions par mois
# ──────────────────────────────────────────────
st.subheader("📈 Évolution des admissions par mois")
try:
    df = query("""
        SELECT annee, mois, SUM(nb_admissions) as total
        FROM gold_frequentation
        GROUP BY annee, mois ORDER BY annee, mois
    """)
    df["periode"] = df["annee"].astype(str) + "-" + df["mois"].astype(str).str.zfill(2)
    fig = px.line(df, x="periode", y="total", markers=True,
                  color_discrete_sequence=["#059669"],
                  labels={"total": "Admissions", "periode": "Période"})
    fig.update_layout(plot_bgcolor="white", margin=dict(l=10, r=10, t=10, b=10))
    fig.update_xaxes(tickangle=45)
    st.plotly_chart(fig, use_container_width=True)
except Exception as e:
    st.error(f"Erreur : {e}")

st.divider()

# ──────────────────────────────────────────────
# Graphique 4 : Coût moyen par service
# ──────────────────────────────────────────────
col_c, col_d = st.columns(2)

with col_c:
    st.subheader("💶 Coût moyen par service")
    try:
        df = query("""
            SELECT service, ROUND(AVG(cout_moyen)::numeric, 0) as cout_moy
            FROM gold_sejour_stats
            GROUP BY service ORDER BY cout_moy DESC
        """)
        fig = px.bar(df, x="service", y="cout_moy",
                     color="cout_moy", color_continuous_scale="Purples",
                     labels={"cout_moy": "Coût moyen ($)", "service": "Service"})
        fig.update_layout(coloraxis_showscale=False, plot_bgcolor="white",
                          xaxis_tickangle=30, margin=dict(l=10, r=10, t=10, b=60))
        st.plotly_chart(fig, use_container_width=True)
    except Exception as e:
        st.error(f"Erreur : {e}")

with col_d:
    st.subheader("👥 Répartition H/F par service")
    try:
        df = query("""
            SELECT service,
                   ROUND(AVG(pct_femmes)*100, 1) as pct_femmes,
                   ROUND((1-AVG(pct_femmes))*100, 1) as pct_hommes
            FROM gold_frequentation
            GROUP BY service
        """)
        fig = go.Figure()
        fig.add_bar(name="Femmes", x=df["service"], y=df["pct_femmes"],
                    marker_color="#EC4899")
        fig.add_bar(name="Hommes", x=df["service"], y=df["pct_hommes"],
                    marker_color="#3B82F6")
        fig.update_layout(barmode="stack", plot_bgcolor="white",
                          xaxis_tickangle=30, margin=dict(l=10, r=10, t=10, b=60),
                          legend=dict(orientation="h", yanchor="bottom", y=1.02))
        st.plotly_chart(fig, use_container_width=True)
    except Exception as e:
        st.error(f"Erreur : {e}")

# Footer
st.markdown("""
<div style='text-align:center;color:#64748B;margin-top:20px;font-size:0.85rem'>
    Pipeline ETL Hospitalier — Groupe 3 · OUALI Leticia & BOUIMEDJ Wafi · Avril 2026
</div>
""", unsafe_allow_html=True)
