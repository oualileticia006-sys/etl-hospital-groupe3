"""
dags/dag_hospital_etl.py
------------------------
DAG Airflow — Pipeline ETL Hospitalier

Orchestration :
  download_data → bronze_extract → silver_transform → gold_aggregate → notify_success

Schedule : @daily (minuit chaque nuit)
Retries  : 2 tentatives avec délai de 5 minutes
"""

import os
from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
from airflow.utils.dates import days_ago

# ──────────────────────────────────────────────
# Configuration par défaut du DAG
# ──────────────────────────────────────────────

default_args = {
    "owner":            "groupe3",
    "depends_on_past":  False,
    "email_on_failure": False,
    "email_on_retry":   False,
    "retries":          2,
    "retry_delay":      timedelta(minutes=5),
    "execution_timeout": timedelta(hours=2),
}

DATA_PATH = os.getenv("DATA_PATH", "/opt/airflow/data")


# ──────────────────────────────────────────────
# Fonctions Python appelées par les tâches
# ──────────────────────────────────────────────

def run_bronze(**context):
    """Extraction Bronze — CSV → Parquet."""
    import sys
    sys.path.insert(0, "/opt/airflow/jobs")
    from job_bronze import run
    stats = run(data_path=DATA_PATH)
    # Push XCom pour logging dans les tâches suivantes
    context["ti"].xcom_push(key="bronze_stats", value=stats)
    return stats


def run_silver(**context):
    """Transformation Silver — nettoyage, jointures."""
    import sys
    sys.path.insert(0, "/opt/airflow/jobs")
    from job_silver import run
    run(data_path=DATA_PATH)


def run_gold(**context):
    """Agrégation Gold — → PostgreSQL."""
    import sys
    sys.path.insert(0, "/opt/airflow/jobs")
    from job_gold import run
    run(data_path=DATA_PATH)


def check_source_files(**context):
    """Vérifie la présence des fichiers CSV sources avant de lancer le pipeline."""
    import os
    raw_path = os.path.join(DATA_PATH, "raw")
    required = ["patients.csv", "admissions.csv", "diagnoses.csv", "medications.csv", "billing.csv"]
    missing = [f for f in required if not os.path.exists(os.path.join(raw_path, f))]

    if missing:
        raise FileNotFoundError(
            f"Fichiers CSV manquants dans {raw_path} : {missing}\n"
            "Assurez-vous d'avoir téléchargé le dataset Kaggle dans data/raw/"
        )

    # Log des tailles
    for fname in required:
        fpath = os.path.join(raw_path, fname)
        size_mb = os.path.getsize(fpath) / (1024 * 1024)
        print(f"  ✅ {fname} — {size_mb:.1f} Mo")


def notify_success(**context):
    """Log de fin de pipeline avec résumé."""
    bronze_stats = context["ti"].xcom_pull(key="bronze_stats", task_ids="bronze_extract")
    execution_date = context["ds"]

    print(f"""
    ╔══════════════════════════════════════════════╗
    ║   PIPELINE ETL HOSPITALIER — SUCCÈS ✅        ║
    ╠══════════════════════════════════════════════╣
    ║  Date d'exécution : {execution_date}          ║
    ║  Bronze stats     : {bronze_stats}            ║
    ╚══════════════════════════════════════════════╝
    """)


# ──────────────────────────────────────────────
# Définition du DAG
# ──────────────────────────────────────────────

with DAG(
    dag_id="hospital_etl_pipeline",
    description="Pipeline ETL Hospitalier — CSV Kaggle → PostgreSQL Gold",
    default_args=default_args,
    schedule_interval="@daily",       # 00:00 chaque nuit
    start_date=days_ago(1),
    catchup=False,
    tags=["etl", "hospital", "spark", "groupe3"],
    doc_md="""
    ## Pipeline ETL Hospitalier — Groupe 3

    Ce DAG orchestre le pipeline ETL complet :

    1. **check_source_files** : Vérifie la présence des CSV dans `data/raw/`
    2. **bronze_extract** : Lit les CSV et les sauvegarde en Parquet (couche Bronze)
    3. **silver_transform** : Nettoie, normalise et joint les données (couche Silver)
    4. **gold_aggregate** : Calcule les agrégations et charge dans PostgreSQL (couche Gold)
    5. **notify_success** : Log de confirmation de fin de pipeline

    ### Dataset
    Hospital Patient Records — [Kaggle](https://www.kaggle.com/datasets/blueblushed/hospital-dataset-for-practice)

    ### Infrastructure
    PySpark local → Parquet → PostgreSQL → Metabase/Streamlit
    """,
) as dag:

    # ── Task 1 : Vérification des sources ────────
    check_sources = PythonOperator(
        task_id="check_source_files",
        python_callable=check_source_files,
        doc_md="Vérifie que tous les CSV sources sont présents dans data/raw/",
    )

    # ── Task 2 : Extraction Bronze ───────────────
    bronze_extract = PythonOperator(
        task_id="bronze_extract",
        python_callable=run_bronze,
        doc_md="Lecture des CSV → Parquet (couche Bronze). Aucune transformation.",
    )

    # ── Task 3 : Transformation Silver ──────────
    silver_transform = PythonOperator(
        task_id="silver_transform",
        python_callable=run_silver,
        doc_md="Nettoyage, normalisation, jointures → Silver Parquet.",
    )

    # ── Task 4 : Agrégation Gold → PostgreSQL ───
    gold_aggregate = PythonOperator(
        task_id="gold_aggregate",
        python_callable=run_gold,
        doc_md="Agrégations analytiques → PostgreSQL (couche Gold).",
    )

    # ── Task 5 : Notification de succès ─────────
    notify = PythonOperator(
        task_id="notify_success",
        python_callable=notify_success,
        doc_md="Log synthétique de fin de pipeline.",
    )

    # ── Dépendances ──────────────────────────────
    check_sources >> bronze_extract >> silver_transform >> gold_aggregate >> notify
