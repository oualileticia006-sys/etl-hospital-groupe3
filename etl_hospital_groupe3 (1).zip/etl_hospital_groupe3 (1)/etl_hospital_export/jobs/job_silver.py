"""
jobs/job_silver.py
------------------
Couche SILVER — Nettoyage, normalisation et jointures.

Transformations appliquées :
  - Suppression des doublons sur id_admission
  - Normalisation des dates au format ISO 8601
  - Cast des colonnes numériques
  - Filtrage des lignes invalides → quarantine/
  - Jointure patients ↔ admissions ↔ diagnoses ↔ billing
  - Calcul de la durée de séjour en jours
"""

import os
import sys

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import DoubleType, IntegerType, DateType

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from jobs.utils.spark_session import get_spark_session
from jobs.utils.logger import JobLogger, get_logger

logger = get_logger(__name__)


# ──────────────────────────────────────────────
# Helpers de nettoyage
# ──────────────────────────────────────────────

def normalize_dates(df: DataFrame, col_name: str) -> DataFrame:
    """
    Normalise une colonne date en gérant les deux formats courants :
      - MM/DD/YYYY  →  yyyy-MM-dd
      - YYYY-MM-DD  →  déjà correct
    Retourne null si aucun format ne correspond (capturé en quarantaine).
    Utilise try_to_date (Spark 3.5+) pour ne pas lever d'exception en mode ANSI.
    """
    return df.withColumn(
        col_name,
        F.coalesce(
            F.to_date(F.col(col_name), "MM/dd/yyyy"),
            F.to_date(F.col(col_name), "yyyy-MM-dd"),
            F.to_date(F.col(col_name), "dd-MM-yyyy"),
        )
    )


def clean_patients(df: DataFrame) -> tuple[DataFrame, DataFrame]:
    """Nettoyage de la table patients."""
    # Doublons par id_patient
    df_dedup = df.dropDuplicates(["id_patient"])

    # Lignes valides
    valid = df_dedup.filter(
        F.col("id_patient").isNotNull() &
        F.col("age").isNotNull() &
        (F.col("age").cast(IntegerType()) > 0) &
        (F.col("age").cast(IntegerType()) < 120)
    ).withColumn("age", F.col("age").cast(IntegerType()))

    # Quarantaine
    quarantine = df_dedup.filter(
        F.col("id_patient").isNull() |
        F.col("age").isNull() |
        (F.col("age").cast(IntegerType()) <= 0) |
        (F.col("age").cast(IntegerType()) >= 120)
    ).withColumn("_raison_rejet", F.lit("patients: age invalide ou id_patient null"))

    logger.info(f"  patients  — valides: {valid.count():,}, quarantaine: {quarantine.count():,}")
    return valid, quarantine


def clean_admissions(df: DataFrame) -> tuple[DataFrame, DataFrame]:
    """Nettoyage et normalisation des admissions."""
    df_dedup = df.dropDuplicates(["id_admission"])
    df_dates = normalize_dates(df_dedup, "date_entree")
    df_dates = normalize_dates(df_dates, "date_sortie")

    # Durée de séjour en jours
    df_dates = df_dates.withColumn(
        "duree_sejour_jours",
        F.datediff(F.col("date_sortie"), F.col("date_entree")).cast(IntegerType())
    )

    # Valides : date_entree non null, durée ≥ 0
    valid = df_dates.filter(
        F.col("id_admission").isNotNull() &
        F.col("id_patient").isNotNull() &
        F.col("date_entree").isNotNull() &
        (
            F.col("date_sortie").isNull() |  # encore hospitalisé
            (F.col("duree_sejour_jours") >= 0)
        )
    )

    quarantine = df_dates.filter(
        F.col("id_admission").isNull() |
        F.col("id_patient").isNull() |
        F.col("date_entree").isNull() |
        (
            F.col("date_sortie").isNotNull() &
            (F.col("duree_sejour_jours") < 0)
        )
    ).withColumn("_raison_rejet", F.lit("admissions: id null ou date_sortie antérieure à date_entree"))

    logger.info(f"  admissions — valides: {valid.count():,}, quarantaine: {quarantine.count():,}")
    return valid, quarantine


def clean_diagnoses(df: DataFrame) -> tuple[DataFrame, DataFrame]:
    """Normalisation des codes ICD (uppercase) et filtrage."""
    df_clean = df.withColumn(
        "code_icd",
        F.upper(F.trim(F.col("code_icd")))
    ).withColumn(
        "description",
        F.trim(F.col("description"))
    )

    valid = df_clean.filter(F.col("id_admission").isNotNull())
    quarantine = df_clean.filter(F.col("id_admission").isNull()) \
        .withColumn("_raison_rejet", F.lit("diagnoses: id_admission null"))

    logger.info(f"  diagnoses  — valides: {valid.count():,}, quarantaine: {quarantine.count():,}")
    return valid, quarantine


def clean_medications(df: DataFrame) -> tuple[DataFrame, DataFrame]:
    """Nettoyage des médicaments."""
    df_clean = df.withColumn(
        "medicament", F.trim(F.upper(F.col("medicament")))
    ).withColumn(
        "duree_jours",
        F.col("duree").cast(IntegerType())
    )

    valid = df_clean.filter(
        F.col("id_admission").isNotNull() &
        F.col("medicament").isNotNull()
    )
    quarantine = df_clean.filter(
        F.col("id_admission").isNull() | F.col("medicament").isNull()
    ).withColumn("_raison_rejet", F.lit("medications: id_admission ou médicament null"))

    logger.info(f"  medications — valides: {valid.count():,}, quarantaine: {quarantine.count():,}")
    return valid, quarantine


def clean_billing(df: DataFrame) -> tuple[DataFrame, DataFrame]:
    """Cast des montants et filtrage des valeurs négatives."""
    df_clean = df.withColumn(
        "montant_total",
        F.col("montant_total").cast(DoubleType())
    )

    valid = df_clean.filter(
        F.col("id_admission").isNotNull() &
        F.col("montant_total").isNotNull() &
        (F.col("montant_total") > 0)
    )
    quarantine = df_clean.filter(
        F.col("id_admission").isNull() |
        F.col("montant_total").isNull() |
        (F.col("montant_total") <= 0)
    ).withColumn("_raison_rejet", F.lit("billing: montant nul, négatif ou id_admission null"))

    logger.info(f"  billing    — valides: {valid.count():,}, quarantaine: {quarantine.count():,}")
    return valid, quarantine


# ──────────────────────────────────────────────
# Jointure principale
# ──────────────────────────────────────────────

def build_silver_master(
    patients:    DataFrame,
    admissions:  DataFrame,
    diagnoses:   DataFrame,
    billing:     DataFrame,
) -> DataFrame:
    """
    Jointure centrale : admissions → patients → diagnoses → billing.
    Résultat : une ligne par admission (avec le diagnostic principal).
    """
    # Diagnostic principal par admission (premier code ICD)
    diag_principal = (
        diagnoses
        .groupBy("id_admission")
        .agg(
            F.first("code_icd").alias("code_icd_principal"),
            F.first("description").alias("description_pathologie"),
            F.count("*").alias("nb_diagnostics")
        )
    )

    master = (
        admissions
        .join(patients,      on="id_patient",   how="left")
        .join(diag_principal, on="id_admission", how="left")
        .join(billing,        on="id_admission", how="left")
        .select(
            # Admission
            "id_admission",
            "id_patient",
            "date_entree",
            "date_sortie",
            "service",
            "duree_sejour_jours",
            # Patient
            F.col("age").alias("age_patient"),
            F.col("sexe").alias("sexe_patient"),
            F.col("ville").alias("ville_patient"),
            # Diagnostic
            "code_icd_principal",
            "description_pathologie",
            "nb_diagnostics",
            # Facturation
            "montant_total",
            "mode_paiement",
            # Dimensions temporelles (utiles pour partitionnement)
            F.year("date_entree").alias("annee"),
            F.month("date_entree").alias("mois"),
        )
    )

    # Cache car réutilisé par plusieurs agrégations Gold
    master.cache()
    logger.info(f"  Silver master (jointure) : {master.count():,} lignes")
    return master


# ──────────────────────────────────────────────
# Job principal
# ──────────────────────────────────────────────

def run(data_path: str = None):
    if data_path is None:
        data_path = os.getenv("DATA_PATH", "/opt/airflow/data")

    bronze_path     = os.path.join(data_path, "bronze")
    silver_path     = os.path.join(data_path, "silver")
    quarantine_path = os.path.join(data_path, "quarantine")

    with JobLogger("ETL_Silver_Transform") as log:
        spark = get_spark_session("Hospital_Silver")

        # ── Lecture Bronze ────────────────────────────
        log.info("Lecture des données Bronze…")
        raw_patients    = spark.read.parquet(os.path.join(bronze_path, "patients"))
        raw_admissions  = spark.read.parquet(os.path.join(bronze_path, "admissions"))
        raw_diagnoses   = spark.read.parquet(os.path.join(bronze_path, "diagnoses"))
        raw_medications = spark.read.parquet(os.path.join(bronze_path, "medications"))
        raw_billing     = spark.read.parquet(os.path.join(bronze_path, "billing"))

        # ── Nettoyage par table ──────────────────────
        log.info("Nettoyage et validation…")
        patients,    q_patients    = clean_patients(raw_patients)
        admissions,  q_admissions  = clean_admissions(raw_admissions)
        diagnoses,   q_diagnoses   = clean_diagnoses(raw_diagnoses)
        medications, q_medications = clean_medications(raw_medications)
        billing,     q_billing     = clean_billing(raw_billing)

        # ── Sauvegarde quarantaine ───────────────────
        log.info("Écriture des lignes en quarantaine…")
        all_quarantine_tables = {
            "q_patients":    q_patients,
            "q_admissions":  q_admissions,
            "q_diagnoses":   q_diagnoses,
            "q_medications": q_medications,
            "q_billing":     q_billing,
        }
        for name, df in all_quarantine_tables.items():
            out = os.path.join(quarantine_path, name)
            df.write.mode("overwrite").parquet(out)

        # ── Jointure Silver Master ───────────────────
        log.info("Construction du Silver Master (jointure)…")
        silver_master = build_silver_master(patients, admissions, diagnoses, billing)

        silver_master.write \
            .mode("overwrite") \
            .parquet(os.path.join(silver_path, "silver_master"))

        # ── Medications Silver ───────────────────────
        log.info("Sauvegarde Silver Medications…")
        medications.write \
            .mode("overwrite") \
            .parquet(os.path.join(silver_path, "silver_medications"))

        log.info("Silver terminé avec succès.")
        spark.stop()


if __name__ == "__main__":
    run()
