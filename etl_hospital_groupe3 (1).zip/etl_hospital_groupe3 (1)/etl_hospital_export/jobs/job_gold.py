"""
jobs/job_gold.py
----------------
Couche GOLD — Agrégations finales → PostgreSQL.

Tables produites :
  1. gold_sejour_stats     — durée de séjour, coût, taux de réadmission par service/pathologie/mois
  2. gold_medication_stats — médicaments les plus prescrits par service
  3. gold_frequentation    — fréquentation mensuelle par service
  4. gold_kpi_dashboard    — KPIs synthétiques du tableau de bord
"""
from pyspark.sql.types import StructType, StructField, DateType, StringType, FloatType
import os
import sys
from datetime import date

from pyspark.sql import SparkSession, DataFrame, Window
from pyspark.sql import functions as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from jobs.utils.spark_session import get_spark_session, get_jdbc_url, get_jdbc_properties
from jobs.utils.logger import JobLogger, get_logger

logger = get_logger(__name__)


# ──────────────────────────────────────────────
# Écriture JDBC vers PostgreSQL
# ──────────────────────────────────────────────

def write_to_postgres(df: DataFrame, table_name: str, mode: str = "overwrite"):
    """Écrit un DataFrame dans PostgreSQL via JDBC."""
    count = df.count()
    logger.info(f"  → {table_name} : {count:,} lignes")

    (
        df.write
        .option("truncate", "true")
        .jdbc(
            url=get_jdbc_url(),
            table=table_name,
            mode=mode,
            properties=get_jdbc_properties(),
        )
    )
    logger.info(f"  ✅ Chargé dans PostgreSQL : {table_name}")
    return count


# ──────────────────────────────────────────────
# Agrégation 1 : Statistiques de séjour
# ──────────────────────────────────────────────

def build_sejour_stats(silver: DataFrame) -> DataFrame:
    """
    Agrégations par (annee, mois, service, code_icd) :
      - Nombre d'admissions
      - Durée moyenne / min / max de séjour
      - Coût moyen et total
      - Taux de réadmission (patients hospitalisés > 1 fois dans la période)
    """
    # Patients réadmis dans la même période
    readmissions = (
        silver
        .filter(F.col("duree_sejour_jours").isNotNull())
        .groupBy("id_patient", "annee", "mois")
        .agg(F.count("id_admission").alias("nb_sejours"))
        .filter(F.col("nb_sejours") > 1)
        .select("id_patient", "annee", "mois",
                F.lit(1).cast("integer").alias("est_readmis"))
    )

    silver_enriched = silver.join(
        readmissions, on=["id_patient", "annee", "mois"], how="left"
    ).withColumn(
        "est_readmis", F.coalesce(F.col("est_readmis"), F.lit(0))
    )

    stats = (
        silver_enriched
        .filter(F.col("annee").isNotNull())
        .groupBy("annee", "mois", "service", "code_icd_principal", "description_pathologie")
        .agg(
            F.count("id_admission").alias("nb_admissions"),
            F.round(F.avg("duree_sejour_jours"), 2).alias("duree_sejour_moy"),
            F.min("duree_sejour_jours").alias("duree_sejour_min"),
            F.max("duree_sejour_jours").alias("duree_sejour_max"),
            F.round(F.avg("montant_total"), 2).alias("cout_moyen"),
            F.round(F.sum("montant_total"), 2).alias("cout_total"),
            F.round(F.avg("est_readmis"), 4).alias("taux_readmission"),
        )
    )
    return stats


# ──────────────────────────────────────────────
# Agrégation 2 : Statistiques médicaments
# ──────────────────────────────────────────────

def build_medication_stats(silver: DataFrame, medications: DataFrame) -> DataFrame:
    """
    Jointure medications ↔ silver pour récupérer service + période.
    Agrégation par (annee, mois, service, médicament).
    """
    med_enriched = (
        medications
        .join(
            silver.select("id_admission", "service", "annee", "mois", "id_patient"),
            on="id_admission", how="left"
        )
        .filter(
            F.col("service").isNotNull() &
            F.col("annee").isNotNull()
        )
    )

    # Agrégation
    agg = (
        med_enriched
        .groupBy("annee", "mois", "service", "medicament")
        .agg(
            F.count("*").alias("nb_prescriptions"),
            F.countDistinct("id_patient").alias("nb_patients_uniques"),
            F.round(F.avg("duree_jours"), 1).alias("duree_moy_jours"),
        )
    )

    # Rang par service (médicament le plus prescrit = rang 1)
    window_service = Window.partitionBy("annee", "mois", "service") \
        .orderBy(F.desc("nb_prescriptions"))
    agg = agg.withColumn("rang_service", F.rank().over(window_service))

    return agg


# ──────────────────────────────────────────────
# Agrégation 3 : Fréquentation mensuelle
# ──────────────────────────────────────────────

def build_frequentation(silver: DataFrame) -> DataFrame:
    """
    Fréquentation par (annee, mois, service) avec démographie et mode de paiement dominant.
    """
    # Mode de paiement le plus fréquent par service/période
    mode_paiement_window = Window.partitionBy("annee", "mois", "service") \
        .orderBy(F.desc("nb_mode"))

    top_paiement = (
        silver
        .filter(F.col("mode_paiement").isNotNull())
        .groupBy("annee", "mois", "service", "mode_paiement")
        .agg(F.count("*").alias("nb_mode"))
        .withColumn("rang_paiement", F.rank().over(mode_paiement_window))
        .filter(F.col("rang_paiement") == 1)
        .select("annee", "mois", "service",
                F.col("mode_paiement").alias("mode_paiement_top"))
    )

    freq = (
        silver
        .filter(F.col("annee").isNotNull())
        .groupBy("annee", "mois", "service")
        .agg(
            F.count("id_admission").alias("nb_admissions"),
            F.countDistinct("id_patient").alias("nb_patients_uniques"),
            F.round(F.avg("age_patient"), 1).alias("age_moyen_patients"),
            F.round(
                F.avg(F.when(F.col("sexe_patient") == "F", 1).otherwise(0)), 4
            ).alias("pct_femmes"),
        )
        .join(top_paiement, on=["annee", "mois", "service"], how="left")
    )

    # Taux d'occupation approximé : nb_admissions / (30 * nb_services)
    freq = freq.withColumn(
        "taux_occupation",
        F.round(F.col("nb_admissions") / 30.0, 4)
    )

    return freq


# ──────────────────────────────────────────────
# Agrégation 4 : KPI Dashboard synthétique
# ──────────────────────────────────────────────

def build_kpi_dashboard(sejour_stats: DataFrame) -> DataFrame:
    """Construit un tableau de KPIs synthétiques pour la direction."""
    from datetime import date
    today = str(date.today())  # "2026-05-10"

    # KPIs agrégés sur la période la plus récente
    latest = sejour_stats.agg(
        F.max("annee").alias("annee_max"),
        F.max("mois").alias("mois_max")
    ).collect()[0]

    recent = sejour_stats.filter(
        (F.col("annee") == latest["annee_max"]) &
        (F.col("mois") == latest["mois_max"])
    )

    kpis_raw = recent.agg(
        F.sum("nb_admissions").alias("total_admissions"),
        F.round(F.avg("duree_sejour_moy"), 2).alias("duree_sejour_globale"),
        F.round(F.avg("cout_moyen"), 2).alias("cout_moyen_global"),
        F.round(F.avg("taux_readmission"), 4).alias("taux_readmission_global"),
    ).collect()[0]

    rows = [
        (today, "total_admissions",       float(kpis_raw["total_admissions"] or 0),       "admissions", None),
        (today, "duree_sejour_moy_jours", float(kpis_raw["duree_sejour_globale"] or 0),    "jours",      None),
        (today, "cout_moyen_admission",   float(kpis_raw["cout_moyen_global"] or 0),       "USD",        None),
        (today, "taux_readmission",       float(kpis_raw["taux_readmission_global"] or 0), "%",          None),
    ]

   
    schema = StructType([
        StructField("date_calcul", StringType(), True),
        StructField("kpi_name",    StringType(), True),
        StructField("kpi_value",   FloatType(),  True),
        StructField("kpi_unit",    StringType(), True),
        StructField("service",     StringType(), True),
    ])
    spark = sejour_stats.sparkSession
    kpi_df = spark.createDataFrame(rows, schema=schema)
    kpi_df = kpi_df.withColumn("date_calcul", F.to_date(F.col("date_calcul")))
    return kpi_df

# ──────────────────────────────────────────────
# Job principal
# ──────────────────────────────────────────────

def run(data_path: str = None):
    if data_path is None:
        data_path = os.getenv("DATA_PATH", "/opt/airflow/data")

    silver_path = os.path.join(data_path, "silver")

    with JobLogger("ETL_Gold_Aggregate") as log:
        spark = get_spark_session("Hospital_Gold")

        # ── Lecture Silver ────────────────────────────
        log.info("Lecture Silver Master…")
        silver      = spark.read.parquet(os.path.join(silver_path, "silver_master"))
        medications = spark.read.parquet(os.path.join(silver_path, "silver_medications"))

        # Cache de la table centrale
        silver.cache()
        log.info(f"  Silver Master chargé : {silver.count():,} lignes")

        # ── Agrégations ───────────────────────────────
        log.info("Calcul gold_sejour_stats…")
        sejour_stats = build_sejour_stats(silver)
        sejour_stats = sejour_stats.withColumnRenamed("code_icd_principal", "code_icd")
        write_to_postgres(sejour_stats, "gold_sejour_stats")

        log.info("Calcul gold_medication_stats…")
        med_stats = build_medication_stats(silver, medications)
        write_to_postgres(med_stats, "gold_medication_stats")

        log.info("Calcul gold_frequentation…")
        frequentation = build_frequentation(silver)
        write_to_postgres(frequentation, "gold_frequentation")

        log.info("Calcul gold_kpi_dashboard…")
        kpis = build_kpi_dashboard(sejour_stats)
        write_to_postgres(kpis, "gold_kpi_dashboard", mode="append")

        silver.unpersist()
        spark.stop()
        log.info("Gold terminé avec succès ✅")


if __name__ == "__main__":
    run()
