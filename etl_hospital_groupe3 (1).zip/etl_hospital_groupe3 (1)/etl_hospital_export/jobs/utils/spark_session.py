"""
jobs/utils/spark_session.py
---------------------------
Utilitaire pour créer et configurer une SparkSession partagée.
"""

import os
import logging
from pyspark.sql import SparkSession

logger = logging.getLogger(__name__)


def get_spark_session(app_name: str = "HospitalETL") -> SparkSession:
    """
    Crée ou récupère une SparkSession configurée pour le projet.
    Compatible avec le mode local (Docker) et un cluster Spark distant.
    """
    spark_master = os.getenv("SPARK_MASTER", "local[*]")
    driver_memory = os.getenv("SPARK_DRIVER_MEMORY", "2g")

    postgres_host = os.getenv("POSTGRES_HOST", "postgres")
    postgres_port = os.getenv("POSTGRES_PORT", "5432")

    logger.info(f"[SparkSession] Initialisation — master={spark_master}, app={app_name}")

    spark = (
        SparkSession.builder
        .appName(app_name)
        .master(spark_master)
        .config("spark.driver.memory", driver_memory)
        .config("spark.sql.shuffle.partitions", "4")          # adapté au mode local
        .config("spark.sql.legacy.timeParserPolicy", "LEGACY") # souplesse formats dates
        .config("spark.sql.parquet.compression.codec", "snappy")
        .config(
            "spark.jars.packages",
            "org.postgresql:postgresql:42.7.1"                 # JDBC driver PostgreSQL
        )
        .config(
            "spark.jars.ivy",
            "/tmp/.ivy2"
        )
        .getOrCreate()
    )

    spark.sparkContext.setLogLevel("WARN")
    logger.info(f"[SparkSession] Démarrée — Spark {spark.version}")
    return spark


def get_jdbc_url() -> str:
    host = os.getenv("POSTGRES_HOST", "postgres")
    port = os.getenv("POSTGRES_PORT", "5432")
    db   = os.getenv("POSTGRES_DB", "hospital_gold")
    return f"jdbc:postgresql://{host}:{port}/{db}"


def get_jdbc_properties() -> dict:
    return {
        "user":     os.getenv("POSTGRES_USER", "hospital_admin"),
        "password": os.getenv("POSTGRES_PASSWORD", ""),
        "driver":   "org.postgresql.Driver",
    }
