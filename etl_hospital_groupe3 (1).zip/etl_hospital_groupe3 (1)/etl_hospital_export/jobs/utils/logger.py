"""
jobs/utils/logger.py
--------------------
Configuration du logging pour tous les jobs ETL.
"""

import logging
import sys
from datetime import datetime


def get_logger(name: str) -> logging.Logger:
    """Retourne un logger configuré avec handlers stdout."""
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger  # déjà configuré

    logger.setLevel(logging.INFO)

    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.INFO)

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    return logger


class JobLogger:
    """
    Context manager pour un job ETL.
    Logue automatiquement le début, la fin et la durée.
    """

    def __init__(self, job_name: str):
        self.job_name  = job_name
        self.logger    = get_logger(job_name)
        self.start_time = None

    def __enter__(self):
        self.start_time = datetime.now()
        self.logger.info(f"{'='*60}")
        self.logger.info(f"DÉMARRAGE du job : {self.job_name}")
        self.logger.info(f"Heure de début   : {self.start_time.strftime('%Y-%m-%d %H:%M:%S')}")
        self.logger.info(f"{'='*60}")
        return self.logger

    def __exit__(self, exc_type, exc_val, exc_tb):
        end_time = datetime.now()
        duration = (end_time - self.start_time).total_seconds()

        if exc_type is None:
            self.logger.info(f"{'='*60}")
            self.logger.info(f"✅ JOB TERMINÉ : {self.job_name}")
            self.logger.info(f"Durée          : {duration:.1f}s")
            self.logger.info(f"{'='*60}")
        else:
            self.logger.error(f"{'='*60}")
            self.logger.error(f"❌ JOB ÉCHOUÉ : {self.job_name}")
            self.logger.error(f"Erreur         : {exc_val}")
            self.logger.error(f"Durée          : {duration:.1f}s")
            self.logger.error(f"{'='*60}")
        return False  # ne supprime pas l'exception
