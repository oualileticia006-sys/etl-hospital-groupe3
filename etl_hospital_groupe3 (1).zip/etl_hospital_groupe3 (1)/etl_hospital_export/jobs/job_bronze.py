"""
jobs/job_bronze.py
------------------
Couche BRONZE — Extraction des CSV bruts vers Parquet.

Principe : copie fidèle de la source, aucune transformation.
Chaque CSV est lu et sauvegardé au format Parquet dans data/bronze/.
Le job est idempotent : overwrite systématique.
"""

import os
import sys
from pyspark.sql import SparkSession, DataFrame

# Ajout du chemin du projet pour les imports relatifs
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from jobs.utils.spark_session import get_spark_session
from jobs.utils.logger import JobLogger, get_logger

logger = get_logger(__name__)

# ──────────────────────────────────────────────
# Configuration des fichiers source
# ──────────────────────────────────────────────
TABLES = {
    "patients":    {"file": "patients.csv",    "has_header": True},
    "admissions":  {"file": "admissions.csv",  "has_header": True},
    "diagnoses":   {"file": "diagnoses.csv",   "has_header": True},
    "medications": {"file": "medications.csv", "has_header": True},
    "billing":     {"file": "billing.csv",     "has_header": True},
}


def read_csv(spark: SparkSession, csv_path: str) -> DataFrame:
    """Lecture d'un CSV avec inférence de schéma."""
    logger.info(f"  Lecture CSV : {csv_path}")
    df = (
        spark.read
        .option("header", "true")
        .option("inferSchema", "true")
        .option("multiLine", "true")
        .option("escape", '"')
        .csv(csv_path)
    )
    return df


def write_bronze(df: DataFrame, output_path: str, table_name: str) -> int:
    """Sauvegarde au format Parquet en mode overwrite (idempotent)."""
    count = df.count()
    logger.info(f"  → {table_name} : {count:,} lignes lues")
    (
        df.write
        .mode("overwrite")
        .parquet(output_path)
    )
    logger.info(f"  ✅ Parquet écrit : {output_path}")
    return count


def run(data_path: str = None):
    """Point d'entrée principal du job Bronze."""
    if data_path is None:
        data_path = os.getenv("DATA_PATH", "/opt/airflow/data")

    raw_path    = os.path.join(data_path, "raw")
    bronze_path = os.path.join(data_path, "bronze")

    with JobLogger("ETL_Bronze_Extract") as log:
        spark = get_spark_session("Hospital_Bronze")
        total_rows = 0
        stats = {}

        for table_name, config in TABLES.items():
            csv_file   = os.path.join(raw_path, config["file"])
            parquet_out = os.path.join(bronze_path, table_name)

            if not os.path.exists(csv_file):
                log.warning(f"  ⚠️  Fichier introuvable (ignoré) : {csv_file}")
                continue

            df = read_csv(spark, csv_file)
            count = write_bronze(df, parquet_out, table_name)
            stats[table_name] = count
            total_rows += count

        # Résumé
        log.info("─" * 50)
        log.info("RÉSUMÉ BRONZE :")
        for table, count in stats.items():
            log.info(f"  {table:<15} : {count:>10,} lignes")
        log.info(f"  {'TOTAL':<15} : {total_rows:>10,} lignes")

        spark.stop()
        return stats


if __name__ == "__main__":
    run()
