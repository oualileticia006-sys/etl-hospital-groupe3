"""
config/generate_dataset.py
--------------------------
Génère un dataset synthétique réaliste pour tester le pipeline
sans avoir à télécharger depuis Kaggle.

Usage :
    python config/generate_dataset.py --rows 50000 --output data/raw/
"""

import os
import random
import argparse
import csv
from datetime import date, timedelta

# ──────────────────────────────────────────────
# Données de référence
# ──────────────────────────────────────────────

SERVICES = ["Cardiologie", "Neurologie", "Orthopédie", "Pédiatrie",
            "Urgences", "Oncologie", "Pneumologie", "Gastroentérologie"]

CODES_ICD = [
    ("I21", "Infarctus aigu du myocarde"),
    ("J18", "Pneumonie à germe non précisé"),
    ("M16", "Coxarthrose"),
    ("G35", "Sclérose en plaques"),
    ("Z38", "Enfants nés vivants"),
    ("C34", "Tumeur maligne des bronches et des poumons"),
    ("K35", "Appendicite aiguë avec péritonite"),
    ("N18", "Maladie rénale chronique"),
    ("E11", "Diabète de type 2"),
    ("I50", "Insuffisance cardiaque"),
]

MEDICAMENTS = [
    ("METOPROLOL", 25), ("ASPIRINE", 100), ("AMOXICILLINE", 500),
    ("IBUPROFENE", 400), ("PARACETAMOL", 1000), ("AMLODIPINE", 5),
    ("ATORVASTATINE", 20), ("OMEPRAZOLE", 20), ("METFORMINE", 850),
    ("RAMIPRIL", 5), ("FUROSEMIDE", 40), ("SPIRONOLACTONE", 25),
    ("CLOPIDOGREL", 75), ("ENOXAPARINE", 40), ("MORPHINE", 10),
]

MODES_PAIEMENT = ["Sécurité Sociale", "Mutuelle", "Carte bancaire", "Espèces", "Chèque"]

VILLES = ["Paris", "Lyon", "Marseille", "Bordeaux", "Lille",
          "Toulouse", "Nantes", "Strasbourg", "Nice", "Rennes"]

SEXES = ["M", "F"]


def random_date(start: date, end: date) -> date:
    return start + timedelta(days=random.randint(0, (end - start).days))


def generate_dataset(n_patients: int, output_dir: str):
    os.makedirs(output_dir, exist_ok=True)

    print(f"Génération du dataset ({n_patients} patients)...")

    # ── patients.csv ─────────────────────────────
    patients = []
    for i in range(1, n_patients + 1):
        patients.append({
            "id_patient":   f"P{i:06d}",
            "nom":          f"Patient_{i}",
            "age":          random.randint(1, 95),
            "sexe":         random.choice(SEXES),
            "ville":        random.choice(VILLES),
        })

    with open(os.path.join(output_dir, "patients.csv"), "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["id_patient", "nom", "age", "sexe", "ville"])
        writer.writeheader()
        writer.writerows(patients)
    print(f"  ✅ patients.csv — {len(patients):,} lignes")

    # ── admissions.csv ────────────────────────────
    admissions = []
    start_date = date(2023, 1, 1)
    end_date   = date(2024, 12, 31)

    n_admissions = int(n_patients * 1.5)  # certains patients réadmis

    for i in range(1, n_admissions + 1):
        patient    = random.choice(patients)
        date_entree = random_date(start_date, end_date)
        duree       = random.randint(1, 30)
        date_sortie = date_entree + timedelta(days=duree)

        # Introduire des problèmes de qualité intentionnels (~5%)
        if random.random() < 0.03:
            date_entree_str = date_entree.strftime("%m/%d/%Y")  # format US
        else:
            date_entree_str = date_entree.strftime("%Y-%m-%d")

        if random.random() < 0.02:
            date_sortie_str = None  # encore hospitalisé
        else:
            date_sortie_str = date_sortie.strftime("%Y-%m-%d")

        admissions.append({
            "id_admission": f"A{i:07d}",
            "id_patient":   patient["id_patient"],
            "date_entree":  date_entree_str,
            "date_sortie":  date_sortie_str,
            "service":      random.choice(SERVICES),
        })

    with open(os.path.join(output_dir, "admissions.csv"), "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["id_admission", "id_patient", "date_entree", "date_sortie", "service"])
        writer.writeheader()
        writer.writerows(admissions)
    print(f"  ✅ admissions.csv — {len(admissions):,} lignes")

    # ── diagnoses.csv ─────────────────────────────
    diagnoses = []
    for adm in admissions:
        nb_diags = random.randint(1, 3)
        selected_codes = random.sample(CODES_ICD, min(nb_diags, len(CODES_ICD)))
        for code, desc in selected_codes:
            # Introduire des codes mixtes majuscules/minuscules (~10%)
            if random.random() < 0.1:
                code = code.lower()
            diagnoses.append({
                "id_admission": adm["id_admission"],
                "code_icd":     code,
                "description":  desc,
            })

    with open(os.path.join(output_dir, "diagnoses.csv"), "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["id_admission", "code_icd", "description"])
        writer.writeheader()
        writer.writerows(diagnoses)
    print(f"  ✅ diagnoses.csv — {len(diagnoses):,} lignes")

    # ── medications.csv ───────────────────────────
    medications = []
    for adm in admissions:
        nb_meds = random.randint(1, 4)
        selected_meds = random.sample(MEDICAMENTS, min(nb_meds, len(MEDICAMENTS)))
        for med, dosage in selected_meds:
            medications.append({
                "id_admission": adm["id_admission"],
                "medicament":   med,
                "dosage":       f"{dosage}mg",
                "duree":        random.randint(3, 30),
            })

    with open(os.path.join(output_dir, "medications.csv"), "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["id_admission", "medicament", "dosage", "duree"])
        writer.writeheader()
        writer.writerows(medications)
    print(f"  ✅ medications.csv — {len(medications):,} lignes")

    # ── billing.csv ───────────────────────────────
    billing = []
    for adm in admissions:
        montant = round(random.uniform(500, 25000), 2)
        # Introduire des montants nuls (~3%)
        if random.random() < 0.03:
            montant = None
        billing.append({
            "id_admission":  adm["id_admission"],
            "montant_total": montant,
            "mode_paiement": random.choice(MODES_PAIEMENT),
        })

    with open(os.path.join(output_dir, "billing.csv"), "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["id_admission", "montant_total", "mode_paiement"])
        writer.writeheader()
        writer.writerows(billing)
    print(f"  ✅ billing.csv — {len(billing):,} lignes")

    total = len(patients) + len(admissions) + len(diagnoses) + len(medications) + len(billing)
    print(f"\n  📊 TOTAL : {total:,} lignes dans 5 fichiers CSV")
    print(f"  📁 Répertoire : {os.path.abspath(output_dir)}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Génère un dataset hospitalier synthétique")
    parser.add_argument("--rows",   type=int, default=10000, help="Nombre de patients (défaut: 10000)")
    parser.add_argument("--output", type=str, default="data/raw/", help="Répertoire de sortie")
    args = parser.parse_args()

    generate_dataset(n_patients=args.rows, output_dir=args.output)
