-- ================================================
-- Initialisation de la base hospital_gold
-- Couche Gold — Tables analytiques finales
-- ================================================

\c hospital_gold;

-- ------------------------------------------------
-- Table 1 : Indicateurs par service et pathologie
-- ------------------------------------------------
CREATE TABLE IF NOT EXISTS gold_sejour_stats (
    id                   SERIAL PRIMARY KEY,
    annee                INTEGER         NOT NULL,
    mois                 INTEGER         NOT NULL,
    service              VARCHAR(100)    NOT NULL,
    code_icd             VARCHAR(20),
    description_pathologie TEXT,
    nb_admissions        INTEGER         NOT NULL DEFAULT 0,
    duree_sejour_moy     NUMERIC(8, 2),  -- en jours
    duree_sejour_min     NUMERIC(8, 2),
    duree_sejour_max     NUMERIC(8, 2),
    cout_moyen           NUMERIC(12, 2), -- en USD
    cout_total           NUMERIC(14, 2),
    taux_readmission     NUMERIC(5, 4),  -- entre 0 et 1
    created_at           TIMESTAMP       DEFAULT NOW(),
    updated_at           TIMESTAMP       DEFAULT NOW()
);

-- ------------------------------------------------
-- Table 2 : Médicaments les plus prescrits
-- ------------------------------------------------
CREATE TABLE IF NOT EXISTS gold_medication_stats (
    id                   SERIAL PRIMARY KEY,
    annee                INTEGER         NOT NULL,
    mois                 INTEGER         NOT NULL,
    service              VARCHAR(100),
    medicament           VARCHAR(200)    NOT NULL,
    nb_prescriptions     INTEGER         NOT NULL DEFAULT 0,
    nb_patients_uniques  INTEGER,
    duree_moy_jours      NUMERIC(6, 1),
    rang_service         INTEGER,        -- rang du médicament dans son service
    created_at           TIMESTAMP       DEFAULT NOW()
);

-- ------------------------------------------------
-- Table 3 : Fréquentation mensuelle par service
-- ------------------------------------------------
CREATE TABLE IF NOT EXISTS gold_frequentation (
    id                   SERIAL PRIMARY KEY,
    annee                INTEGER         NOT NULL,
    mois                 INTEGER         NOT NULL,
    service              VARCHAR(100)    NOT NULL,
    nb_admissions        INTEGER         NOT NULL DEFAULT 0,
    nb_patients_uniques  INTEGER,
    taux_occupation      NUMERIC(5, 4),  -- approximé sur 30j
    age_moyen_patients   NUMERIC(5, 1),
    pct_femmes           NUMERIC(5, 4),
    mode_paiement_top    VARCHAR(50),
    created_at           TIMESTAMP       DEFAULT NOW()
);

-- ------------------------------------------------
-- Table 4 : Tableau de bord synthétique (vue KPI)
-- ------------------------------------------------
CREATE TABLE IF NOT EXISTS gold_kpi_dashboard (
    id                   SERIAL PRIMARY KEY,
    date_calcul          DATE            NOT NULL,
    kpi_name             VARCHAR(100)    NOT NULL,
    kpi_value            NUMERIC(14, 4),
    kpi_unit             VARCHAR(30),
    service              VARCHAR(100),
    variation_pct        NUMERIC(8, 2),  -- vs mois précédent
    created_at           TIMESTAMP       DEFAULT NOW()
);

-- ------------------------------------------------
-- Indexes pour les requêtes dashboard
-- ------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_sejour_stats_annee_mois
    ON gold_sejour_stats (annee, mois);

CREATE INDEX IF NOT EXISTS idx_sejour_stats_service
    ON gold_sejour_stats (service);

CREATE INDEX IF NOT EXISTS idx_medication_stats_annee_mois
    ON gold_medication_stats (annee, mois);

CREATE INDEX IF NOT EXISTS idx_frequentation_annee_mois
    ON gold_frequentation (annee, mois);

CREATE INDEX IF NOT EXISTS idx_kpi_date
    ON gold_kpi_dashboard (date_calcul);

-- ------------------------------------------------
-- Vue pratique pour le dashboard
-- ------------------------------------------------
CREATE OR REPLACE VIEW v_dashboard_principal AS
SELECT
    f.annee,
    f.mois,
    f.service,
    f.nb_admissions,
    s.duree_sejour_moy,
    s.cout_moyen,
    s.taux_readmission,
    f.age_moyen_patients,
    f.pct_femmes
FROM gold_frequentation f
LEFT JOIN (
    SELECT service, annee, mois,
           AVG(duree_sejour_moy)  AS duree_sejour_moy,
           AVG(cout_moyen)        AS cout_moyen,
           AVG(taux_readmission)  AS taux_readmission
    FROM gold_sejour_stats
    GROUP BY service, annee, mois
) s ON f.service = s.service AND f.annee = s.annee AND f.mois = s.mois
ORDER BY f.annee DESC, f.mois DESC, f.service;

COMMENT ON TABLE gold_sejour_stats      IS 'Indicateurs de séjour agrégés par service, pathologie et période';
COMMENT ON TABLE gold_medication_stats  IS 'Statistiques de prescription médicamenteuse par service et période';
COMMENT ON TABLE gold_frequentation     IS 'Fréquentation mensuelle par service hospitalier';
COMMENT ON TABLE gold_kpi_dashboard     IS 'KPIs synthétiques pour le tableau de bord de direction';
